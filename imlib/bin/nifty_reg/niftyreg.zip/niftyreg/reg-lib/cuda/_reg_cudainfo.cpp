#include <iostream>
#include "_reg_common_cuda.h"

void showCUDAInfo(void)
{
    showCUDACardInfo();
}
