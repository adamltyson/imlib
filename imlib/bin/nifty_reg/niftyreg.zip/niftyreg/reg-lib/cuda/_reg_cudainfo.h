#ifndef _REG_COMMON_GPU_H
#define _REG_COMMON_GPU_H

void showCUDAInfo(void);

#endif